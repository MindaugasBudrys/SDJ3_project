﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WebServiceClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            showOrderForArrivalPanel();
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            showOrderForDeparturePanel();
        }

        private void showOrderForDeparturePanel()
        {
            OrderForDeparture.Visibility = Visibility.Visible;
        }

        private void showOrderForArrivalPanel()
        {
            OrderForArrival.Visibility = Visibility.Visible;
        }

        private void AddToListOfOrderForArrival_Click(object sender, RoutedEventArgs e)
        {
            AddToListForArrival();

        }
        private void AddToListOfOrderForDeparture_Click(object sender, RoutedEventArgs e)
        {
            AddToListForDeparture();
        }

        List<String> OrderForDepartList = new List<string>();
        private void AddToListForDeparture()
        {
            String newString = IdDepartValue.Text + "," + QuantDepartValue.Text;
            Console.WriteLine(newString);

            OrderForDepartList.Add(newString);

            ListOfProductsForDepartLabel.Content += "Product: " + newString + "\n";
        }

        List<String> OrderForArrivalList = new List<string>();
        private void AddToListForArrival()
        {
            String newString = IdArrivalValue.Text + "," + QuantArrivalValue.Text;
            Console.WriteLine(newString);

            OrderForArrivalList.Add(newString);

            ListOfProductsForArrivalLabel.Content += "Product: " + newString + "\n";
        }

        private void SendOrderForArrival_Click(object sender, RoutedEventArgs e)
        {
            sendOrderForArrivalToServer();
        }

        private void sendOrderForArrivalToServer()
        {
            String[] arrayOfProducts = new String[OrderForArrivalList.Count];

            for (int i = 0; i < OrderForArrivalList.Count; i++)
            {
                arrayOfProducts[i] = OrderForArrivalList[i];
            }

            OrderForArrivalList.Clear();
            ListOfProductsForArrivalLabel.Content = "";
            string responseFromServer = receiveResponseFromServerArrivalOrder(arrayOfProducts);

        }
        private string receiveResponseFromServerArrivalOrder(string[] arrayOfProducts)
        {
            string result = null;
            WarehouseControlWebService.WebServiceBridgeService service = new WarehouseControlWebService.WebServiceBridgeService();

            result = service.orderProductsForArrivalThroughWebService(arrayOfProducts);

            if (result == null)
            {
                result = "Something went wrong!";
            }

            ResultLabel.Content = result;
            return result;

        }

        private void SendOrderForDepart_Click(object sender, RoutedEventArgs e)
        {
            sendOrderForDepartureToServer();
        }

        private void sendOrderForDepartureToServer()
        {
            String[] arrayOfProducts = new String[OrderForDepartList.Count];

            for (int i = 0; i < OrderForDepartList.Count; i++)
            {
                arrayOfProducts[i] = OrderForDepartList[i];
            }


            OrderForDepartList.Clear();
            ListOfProductsForDepartLabel.Content = "";
            ResultLabel.Content = "";
            string responseFromServer = receiveResponseFromServerDepartOrder(arrayOfProducts);
        }

        private string receiveResponseFromServerDepartOrder(string[] arrayOfProducts)
        {
            string result = null;
            WarehouseControlWebService.WebServiceBridgeService service = new WarehouseControlWebService.WebServiceBridgeService();

            result = service.orderProductsForDepartureThroughWebService(arrayOfProducts);

            if (result == null)
            {
                result = "Something went wrong!";
            }

            ResultLabel.Content = result;
            return result;
            
        }

        private void DisplayProducts_Click(object sender, RoutedEventArgs e)
        {
            string[] result = null;
            WarehouseControlWebService.WebServiceBridgeService service = new WarehouseControlWebService.WebServiceBridgeService();

            result = service.getProductsList();

            ResultLabel.Content = "";
            for (int i = 0; i < result.Length; i++)
            {
                ResultLabel.Content += result[i];
                ResultLabel.Content += "\n";

            }
        }
    }
}
